//
//  LinkTWCell.swift
//  ChartDemo
//
//  Created by Kinjal on 30/05/23.
//

import UIKit

class LinkTWCell: UITableViewCell {
    
    @IBOutlet weak var lblLink: UILabel!
    @IBOutlet weak var view: UIView!
    @IBOutlet weak var btnCopy: UIButton!
    @IBOutlet weak var lblClicks: UILabel!
    @IBOutlet weak var lblScore: UILabel!
    @IBOutlet weak var lblDesc: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgLink: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
