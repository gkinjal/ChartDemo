//
//  TableCVCell.swift
//  ChartDemo
//
//  Created by Kinjal on 30/05/23.
//

import UIKit

class TableCVCell: UICollectionViewCell {
    
    @IBOutlet weak var tableView: UITableView!
}
