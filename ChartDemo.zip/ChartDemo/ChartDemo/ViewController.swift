//
//  ViewController.swift
//  ChartDemo
//
//  Created by Kinjal on 26/05/23.
//

import UIKit
import SwiftChart


class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var tblCollectionView: UICollectionView!
    @IBOutlet weak var btnRecentLinks: UIButton!
    @IBOutlet weak var btnTopLinks: UIButton!
    @IBOutlet weak var btnAnalytics: UIButton!
    @IBOutlet weak var DetailsCV: UICollectionView!
    @IBOutlet weak var viewChart: Chart!
    @IBOutlet weak var lblName: UILabel!
    
    var detailData: Welcome?
    var arrLinks = [Link]()
    var currentIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getRequest() { results in
            self.detailData = results
            if self.detailData != nil {
                DispatchQueue.main.async {
                    self.setupData()
                }
                
            }
        }
    }
    
    @IBAction func onClickTopLinks(_ sender: UIButton) {
        btnTopLinks.layer.cornerRadius = 18
        btnTopLinks.backgroundColor = .blue
        btnTopLinks.setTitleColor(.white, for: .normal)
        
        btnRecentLinks.backgroundColor = .clear
        btnRecentLinks.setTitleColor(.lightGray, for: .normal)
        currentIndex = 0
        tblCollectionView.scrollToItem(at: IndexPath(item: 0, section: 0), at: .right, animated: true)
        tblCollectionView.layoutSubviews()
        
    }
    @IBAction func onClickRecentLinks(_ sender: Any) {
        btnRecentLinks.layer.cornerRadius = 18
        btnRecentLinks.backgroundColor = .blue
        btnRecentLinks.setTitleColor(.white, for: .normal)
        
        btnTopLinks.backgroundColor = .clear
        btnTopLinks.setTitleColor(.lightGray, for: .normal)
        currentIndex = 1
        tblCollectionView.setContentOffset(CGPoint(x: (1) * tblCollectionView.frame.size.width-16, y: 0), animated: true)
        
    }
    @IBAction func onClickSearch(_ sender: Any) {
    }
    
    func getRequest(callback: @escaping (Welcome?) -> Void) {
        let theToken =  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MjU5MjcsImlhdCI6MTY3NDU1MDQ1MH0.dCkW0ox8tbjJA2GgUx2UEwNlbTZ7Rr38PVFJevYcXFI"
        
        if let url = URL(string: "https://api.inopenapp.com/api/v1/dashboardNew") {
            var request = URLRequest(url: url)
            request.allHTTPHeaderFields = [
                "Content-Type": "application/json",
                "Authorization":"Bearer \(theToken)"
            ]
            
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                guard error == nil else { return }
                guard let data = data else { return }
                do {
                    let decoder = JSONDecoder()
                    let codabledata = try decoder.decode(Welcome.self, from: data)
                    callback(codabledata)  // <-- here
                } catch {
                    print(error)
                    callback(nil)  // <-- here
                }
            }.resume()
        }
        
    }
    
    
    func setupData() {
        self.lblName.text = detailData?.supportWhatsappNumber
        
        var data = [Double]()
        
        for i in detailData!.data.overallURLChart {
            data.append(Double(i.value))
        }
        
        let series = ChartSeries(data)
        series.colors = (
            above: ChartColors.blueColor(),
            below: ChartColors.blueColor(),
            zeroLevel: -1
        )
        series.area = true
        
        viewChart.add(series)
        
        // Set minimum and maximum values for y-axis
        viewChart.minY = -7
        viewChart.maxY = 7
        
        // Format y-axis, e.g. with units
        viewChart.yLabelsFormatter = { String(Int($1)) +  "ºC" }
        
        if let recentlink = detailData?.data.recentLinks {
            arrLinks.append(contentsOf: recentlink)
        }
        if let toplink = detailData?.data.topLinks {
            arrLinks.append(contentsOf: toplink)
        }
        DetailsCV.delegate = self
        DetailsCV.dataSource = self
        tblCollectionView.delegate = self
        tblCollectionView.dataSource = self
        DetailsCV.reloadData()
        
        
        
        btnAnalytics.layer.borderColor = UIColor.lightGray.cgColor
        btnAnalytics.layer.borderWidth = 1.0
        btnAnalytics.layer.cornerRadius = 10
        btnAnalytics.clipsToBounds = true
        
        tblCollectionView.reloadData()
        
        onClickTopLinks(UIButton())
    }
}


extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == DetailsCV {
            return arrLinks.count
        }else{
            return 2
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == DetailsCV {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DetailCVCell", for: indexPath) as? DetailCVCell
            
            cell?.lblTitle.text = arrLinks[indexPath.row].title
            cell?.imgDetail.downloaded(from: URL(string: arrLinks[indexPath.row].originalImage)!)
            cell?.lblDesc.text = arrLinks[indexPath.row].timesAgo
            cell?.detailView.layer.cornerRadius = 8.0
            cell?.detailView.clipsToBounds = true
            
            return cell!
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TableCVCell", for: indexPath) as? TableCVCell
            cell?.contentView.backgroundColor = .clear
            cell?.tableView.delegate = self
            cell?.tableView.dataSource = self
            cell?.tableView.register(UINib(nibName:"LinkTWCell" , bundle: nil), forCellReuseIdentifier: "LinkTWCell")
            
            return cell!
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == DetailsCV {
            return CGSize(width: 136, height: 136)
        }else{
            return CGSize(width: tblCollectionView.frame.width-30, height: 250)
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if collectionView == DetailsCV {
            return UIEdgeInsets.init(top: 0.0, left: 16, bottom: 0.0, right: 16)
        }else{
            return UIEdgeInsets.init(top: 0.0, left: 16, bottom: 0.0, right: 16)
        }
    }
    
    
}


extension ViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if currentIndex == 0 {
            return detailData?.data.topLinks.count ?? 0
        }else{
            return detailData?.data.recentLinks.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if currentIndex == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "LinkTWCell") as? LinkTWCell
            cell?.lblTitle.text = detailData?.data.topLinks[indexPath.row].title
            cell?.lblDesc.text = detailData?.data.topLinks[indexPath.row].timesAgo
            cell?.lblScore.text = "\(detailData?.data.topLinks[indexPath.row].totalClicks ?? 0)"
            cell?.lblClicks.text = "Clicks"
            cell?.imgLink.downloaded(from: URL(string: (detailData?.data.topLinks[indexPath.row].originalImage)!)!)
            cell?.view.layer.cornerRadius = 8
            cell?.view.clipsToBounds = true
            cell?.lblLink.text = detailData?.data.topLinks[indexPath.row].webLink
            cell?.btnCopy.addTarget(self, action:#selector(onClickCopy1(_:)), for: .touchUpInside)
            cell?.btnCopy.tag = indexPath.row
            cell?.selectionStyle = .none
            return cell!
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "LinkTWCell") as? LinkTWCell
            cell?.lblTitle.text = detailData?.data.recentLinks[indexPath.row].title
            cell?.lblDesc.text = detailData?.data.recentLinks[indexPath.row].timesAgo
            cell?.lblScore.text = "\(detailData?.data.recentLinks[indexPath.row].totalClicks ?? 0)"
            cell?.lblClicks.text = "Clicks"
            cell?.imgLink.downloaded(from: URL(string: (detailData?.data.recentLinks[indexPath.row].originalImage)!)!)
            cell?.view.layer.cornerRadius = 8
            cell?.view.clipsToBounds = true
            cell?.lblLink.text = detailData?.data.recentLinks[indexPath.row].webLink
            cell?.btnCopy.addTarget(self, action:#selector(onClickCopy(_:)), for: .touchUpInside)
            cell?.btnCopy.tag = indexPath.row
            cell?.selectionStyle = .none
            return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    @objc func onClickCopy(_ sender: UIButton) {
        let pasteboard = UIPasteboard.general
        UIPasteboard.general.string = detailData?.data.recentLinks[sender.tag].webLink
    }
    
    @objc func onClickCopy1(_ sender: UIButton) {
        let pasteboard = UIPasteboard.general
        UIPasteboard.general.string = detailData?.data.topLinks[sender.tag].webLink
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if currentIndex == 0 {
            if let url = URL(string: (detailData?.data.topLinks[indexPath.row].webLink)!){
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }else{
            if let url = URL(string: (detailData?.data.recentLinks[indexPath.row].webLink)!){
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
    }
    
    
}
